<?php
	/**
		Connecting to the database server 
		here: 
		database server name : localhost
		user name : root
		passsword : null password 
	*/
	$dbConnection = mysql_connect("localhost","root","root") or die('Unable to connect to the
database server');

	/**
		Selecting the database need to be used in the application
	*/
	$database = mysql_select_db('school') or die("Unable to select DB");
?>
