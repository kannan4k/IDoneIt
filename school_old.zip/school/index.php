<html>
	<head>
		<link rel="stylesheet" type="text/css" href="web/default.css" />
		<title>::ZRKAC Info::</title>
		<img src="1.jpg" width="500px" height="100px" >
		
	</head>
	<body link="white" vlink="white" alink="white">
		<table width="100%" height="100%">
			<tr>
				<td valign="top">
					
					<table align="center" cellspacing="5" cellpadding="5">
						<tr class="btn">
				<form action="show.php" method="post">
							<tr>
						
							<td><input type="date" value="<?php if(isset($_POST['day'])) echo $_POST['day'];?>" name="day" class="txt"></td>
							<td >
								<input type="submit" value="Select" class="txt" />
							</td>
							</tr>

				</form>	
						</tr>
					</table>
					
		

			</tr>
		</table>
	</body>
</html>
